var socket = io(modNodejsConfig.host, {query: 'ctx=' + modNodejsConfig.ctx});
